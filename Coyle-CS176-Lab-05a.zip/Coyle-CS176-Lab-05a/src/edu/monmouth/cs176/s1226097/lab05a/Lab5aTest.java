package edu.monmouth.cs176.s1226097.lab05a;

public class Lab5aTest 
{
	public static void main(String[] args)
	{
		System.out.println("Lab 5a: "); 
		
		//Initiate StudentList class
		StudentList cs176List = new StudentList(); 
		
		//Initiate new students
		Student s1 = new Student("Ahmed, Saahil", "1219200", "s1219200@monmouth.edu", "CS", 2, "E. Cesario", 1.0, 2022); 
		Student s2 = new Student("Coyle, Shannon", "1226097", "s1226097@monmouth.edu", "SE", 2, "J.Kretsch", 1.0, 2022);
		Student s3 = new Student("Kliks, Angela", "1137151", "s1137151@monmouth.edu", "CS", 2, "L. Zheng", 1.0, 2022);
		Student s4 = new Student("Krempa, Ian", "1233625", "s1233625@monmouth.edu", "CS", 2, "C. Yu", 1.0, 2022);
		
		//Add students to list
		
		cs176List.addStudent(s1);
		cs176List.addStudent(s2);
		
		//Create courses
		Course cs176 = new Course("CS", "176", "Intro to CSII"); 
		Course fys101 = new Course("FYS", "101", "First Year Seminar"); 
		
		// *** Registration instantiation requires course object and an initial grade.
		// *** There can be multiple registrations - one for each student (see below)
		Registration reg0 = new Registration (cs176, 0.0);
		Registration reg1 = new Registration(cs176, 0.0); 
		Registration reg2 = new Registration(fys101, 0.0); 
		
		// *** Each registration from above assigned  to a student
	    s1.addRegistration(reg0);
		
		s2.addRegistration(reg1);
		s2.addRegistration(reg2);
		
		//Lists the students
		cs176List.listStudents();
		
		// Change in grade is for a given registration and given student
		
		cs176List.setCourseGrade("1226097", reg1, 3.99);
		
		cs176List.listStudents();
	}
}
