package edu.monmouth.cs176.s1226097.lab05a;
import java.util.ArrayList;

public class StudentList 
{
	ArrayList<Student> cs176Students = new ArrayList<Student>();  

	private int count = 0; 

	//Constructor for StudentList class
	StudentList()
	{

	}

	/*
	 * @param s - new student object
	 */
	public void addStudent(Student s)
	{
		cs176Students.add(s); 
	}


	//List the students using FOR-EACH LOOP
	public void listStudents()
	{
		for (Student s: cs176Students)
		{
			System.out.println("STUDENT: "); 
			System.out.println(s.toString()); 
			System.out.println(); 
			System.out.println("CLASSES: "); 
			for(Registration r: s.registration)
			{
				System.out.println(r.toString()); 
			}
		}
	}

	public Student Find(String id)
	{
		Student foundStudent = null; 
		for(Student s: cs176Students)
		{
			if((s.getStudentID()) == id)
			{
				return s; 
			}  
		}
		return foundStudent;
	}

	public boolean updateStudentGraduationYear(String studentID, Integer year)
	{
		boolean result = false; 
		Student student = Find(studentID);
		if(student != null)
		{
			student.setGraduationYear(year);
			return true; 
		}
		return result; 
	}

	public int studentCount(String major)
	{
		int numMajor = 0; 
		for(Student s: cs176Students)
		{
			if(s.getMajor() == major)
			{
				numMajor++; 
			}
		}
		return numMajor; 	
	}

	/*public Student getStudentInfo(String email)
	{  
		Student student = FindEmail(email);
		if(student != null)
		{
			return student; 
		}
		else
		{
			return null;
		}
	}
	 */

	public Student findStudentByKey(String key, String value)
	{
		Student foundStudent = null; 
		for(Student s: cs176Students)
		{
			switch(key)
			{
			case("ID"): 
				if(s.getStudentID() == value)
				{
					return s; 
				}
			break; 
			case("email"):
				if(s.getStudentEmail() == value)
				{
					return s; 
				}
			break;
			case("advisor"):
				if(s.getAdvisor() == value)
				{
					return s; 
				}
			break;   
			}
		}
		return foundStudent; 
	}

	public void setCourseGrade(String id, Registration reg, double grade)
	{
		for(Student s: cs176Students)
		{
			//Finds student
			if(s.getStudentID() == id)
			{
				System.out.println("STUDENT: " +s); 
				for (Registration r: s.registration) {
					if (r == reg) {
						r.setGrade(grade);
					}
				}
				
				
			}
		}

	}
}