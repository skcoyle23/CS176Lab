package edu.monmouth.cs176.s1226097;

public class TestInheritance 
{
	public static void main(String[] args) 
	{
		GradStudent gs1 = new GradStudent("Shannon", "Coyle", "MU", 3.8, 2022, 2024, 0.0); 
		GradStudent gs2 = new GradStudent("John", "Smith", "Harvard", 2.55, 2021, 2023, 0.0);
		GradStudent gs3 = new GradStudent("John", "Doe", "NJIT", 4.0, 2020, 2022, 0.0);
		GradStudent gs4 = new GradStudent("Jane", "Doe", "Marist", 3.34, 2021, 2023, 0.0);
		
		gs4.setGradGPA(3.2);
		gs1.setUGGPA(3.75);
		
		System.out.println(gs1.toString()); 
		System.out.println(gs2.toString());
		System.out.println(gs3.toString());
		System.out.println(gs4.toString());
	}
}
