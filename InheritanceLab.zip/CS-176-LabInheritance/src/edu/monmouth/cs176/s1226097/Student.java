package edu.monmouth.cs176.s1226097;

public class Student 
{
	public String firstName; 
	public String lastName; 
	public String school; 
	public Double gpa; 
	public Integer graduationYear; 
	
	Student(String fName, String lName, String schoolN, Double gpa, Integer gradYear)
	{
		this.firstName = fName; 
		this.lastName = lName; 
		this.school = schoolN; 
		this.gpa = gpa; 
		this.graduationYear = gradYear; 
	}
	
	public void setUGGPA(Double newUGGPA)
	{
		this.gpa = newUGGPA; 
	}
	
	public String toString()
	{
		return "First Name: " +this.firstName + " Last Name: " +this.lastName+ " Undergrad School: " 
				+this.school+ " GPA: " +this.gpa+ " Undergrad Graduation Year: " +this.graduationYear; 
	}
}
