package edu.monmouth.cs176.s1226097;

public class GradStudent extends Student 
{
	public Double gradGPA;
	public Integer gradGradYear; 
	
	GradStudent(String fName, String lName, String ugSchool, Double ugGPA, Integer ugGrad, Integer gradGradYear, Double gradGPA)
	{
		super(fName, lName, ugSchool, ugGPA, ugGrad); //Calling info from Student class
		this.gradGPA = gradGPA; 
		this.gradGradYear = gradGradYear; 
	}
	
	public void setGradGPA(Double newGPA)
	{
		this.gradGPA = newGPA; 
	}
	
	public String toString()
	{
		String studentInfo = super.toString(); 
		return studentInfo+ " Grad Graduate Year: " +this.gradGradYear+ " Grad GPA: " +this.gradGPA; 
	}
}
