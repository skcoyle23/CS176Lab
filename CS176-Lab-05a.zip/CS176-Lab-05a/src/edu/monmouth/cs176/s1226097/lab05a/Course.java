package edu.monmouth.cs176.s1226097.lab05a;

public class Course 
{
	//Initializes private variables
	private String courseCode; 
	private String courseNumber; 
	private String courseDescription; 

	//Creates the "Course" class
	Course (String courseCode, String courseNumber, String courseDescription)
	{
		this.courseCode = courseCode; 
		this.courseNumber = courseNumber; 
		this.courseDescription = courseDescription; 
	}

	public Course(Course c) 
	{
		this(c.courseCode, c.courseNumber, c.courseDescription); 
	}

	public String toString()
	{
		return "Course Code: " +this.courseCode+ "\n"+
				"Course Number: " +this.courseNumber+ "\n"+
				"Course Description: " +this.courseDescription;  
	}
	
	public void setDesc(String desc)
	{
		this.courseDescription = desc; 
	}
}
