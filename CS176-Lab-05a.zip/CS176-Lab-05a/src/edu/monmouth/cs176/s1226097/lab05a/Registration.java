package edu.monmouth.cs176.s1226097.lab05a;

public class Registration extends Course
{
	//Initializes private variable
	private double grade;
	
	//Creates the "Registration" class
	Registration(Course course, double initGrade)
	{ 
		super(course); 
		grade = initGrade; 
	}
	
	public void setGrade(double newGrade)
	{
		this.grade = newGrade; 
	}
	
	public double getGrade()
	{
		return this.grade; 
	}

	public String toString()
	{
		return "COURSE: " +super.toString()+ "\n"+
				"GRADE: " +this.grade;
	}
}
