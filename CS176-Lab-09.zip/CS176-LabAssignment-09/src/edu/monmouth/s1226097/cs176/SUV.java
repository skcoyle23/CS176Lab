package edu.monmouth.s1226097.cs176;

public class SUV extends PassengerCar
{
	private int costInc = 4000; 
	
	SUV(Integer ft, Double mpg, Integer pass, Double initPrice)
	{
		super(ft, mpg, pass, initPrice); 
	}
	
	@Override
	public double getPrice()
	{
		if(super.getPassengers() == 7)
		{
			return super.getPrice() + costInc;  
		}
		return super.getPrice(); 
	}
}
