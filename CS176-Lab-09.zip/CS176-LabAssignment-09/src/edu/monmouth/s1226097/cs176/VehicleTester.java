package edu.monmouth.s1226097.cs176;

public class VehicleTester 
{
	public static void main(String[] args) 
	{
		/*
		//(fuel tank, mpg, carrying weight)
		CargoTruck c1 = new CargoTruck(125, 6.0, 1000.0); 
		CargoTruck c2 = new CargoTruck(125, 6.0, 3000.0); 
		CargoTruck c3 = new CargoTruck(125, 6.0, 6000.0);
		CargoTruck c4 = new CargoTruck(125, 6.0, 10000.0);
		
		//(fuel tank, mpg, passengers
		PassengerCar p1 = new PassengerCar(15, 20.0, 4, 20000.0); 
		
		System.out.println(p1.toString()); 
		System.out.println(p1.numberOfStops(3000.0)); 
		System.out.println(); 
		
		System.out.println(c1.toString()); 
		System.out.println(c1.numberOfStops(4000.0));
		System.out.println(); 
		
		System.out.println(c2.toString());
		System.out.println(c2.numberOfStops(6000.0)); 
		System.out.println(); 
		
		System.out.println(c3.toString());
		System.out.println(c3.numberOfStops(3000.0)); 
		System.out.println(); 

		System.out.println(c4.toString()); 
		System.out.println(c4.numberOfStops(7000.0)); 
		System.out.println(); 
		*/
		
		//Instantiates Sedan and SUV
		Sedan v = new Sedan(15, 20.0, 7, 20000.0); 
		SUV v2 = new SUV(15, 20.0, 7, 20000.0); 
		SUV v3 = new SUV(15, 20.0, 5, 20000.0); 
		
		double newSUVP = v2.getPrice(); 
		
		System.out.println(v); 
		System.out.println(); 
		System.out.println(v2); 
		System.out.println("Final Price of SUV: $" +newSUVP); 
		System.out.println(); 
		
		newSUVP = v3.getPrice(); 
		System.out.println(v3); 
		System.out.println("Final Price of SUV: $" +newSUVP);
		
	}

}
