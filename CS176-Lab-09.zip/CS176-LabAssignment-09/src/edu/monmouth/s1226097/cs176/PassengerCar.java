package edu.monmouth.s1226097.cs176;

public class PassengerCar extends Vehicle
{
	private Integer passengers; 
	private Double price; 
	
	PassengerCar(Integer ft, Double mpg, Integer pass, Double initPrice) //Assume mpg doesn't change significantly
	{
		super(ft, mpg); 
		passengers = pass; 
		price = initPrice; 
	}
	
	public void setPassengers(int newPass)
	{
		this.passengers = newPass; 
	}
	
	public int getPassengers()
	{
		return this.passengers; 
	}
	public void setPrice(double newP)
	{
		this.price = newP; 
	}
	
	public double getPrice()
	{
		return price; 
	}
	
	public String toString()
	{
		String vehicleInfo = super.toString(); 
		return vehicleInfo+ " "
				+ "There are " +this.passengers+ " passengers. Initial Price: $" +price; 
	}
}
