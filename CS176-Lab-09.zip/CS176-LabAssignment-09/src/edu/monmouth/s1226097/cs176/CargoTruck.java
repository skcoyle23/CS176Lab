package edu.monmouth.s1226097.cs176;

public class CargoTruck extends Vehicle
{
	private Double carryingWeight; 

	CargoTruck(Integer ft, Double mpg, Double initWeight)
	{
		super(ft, mpg);
		carryingWeight = initWeight; 
	}

	//Distance changes based on carrying weight
	@Override
	public int numberOfStops (Double travDist)
	{
		int stops = 0; 
		double mpg = super.getMPG(); 
		double tempWeight = carryingWeight; 
		
		if(tempWeight < 1000) //Returns normal stops 
		{
			stops = super.numberOfStops(travDist); 
		}
		else if(tempWeight >= 1000)
		{
			int carryingCount = 1; //Follows # of thousands
			
			while(true)
			{
				if(tempWeight - 1000 >= 1000) //Adds count if weight is still over 1000
				{
					carryingCount++; 
					tempWeight = tempWeight-1000; 
				}
				else
				{
					break; 
				}
			}
			double truckReduct = (mpg * (0.02)) * carryingCount; //Calculates the distance traveled change
			System.out.println("MPG Reduced: " +truckReduct);
			
			mpg = mpg - truckReduct; 
			System.out.println("MPG Subtracted: " +mpg); 
			
			super.setMPG(mpg); 
			stops = super.numberOfStops(travDist); 
		}
		return stops; 
	}

	public String toString()
	{
		String vehicleInfo = super.toString(); 
		return vehicleInfo+ " The truck has a carrying weight of " +carryingWeight; 
	}
}
