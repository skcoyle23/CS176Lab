package edu.monmouth.s1226097.cs176;

public class Sedan extends PassengerCar
{
	Sedan(Integer ft, Double mpg, Integer pass, Double initPrice)
	{
		super(ft, mpg, pass, initPrice); 
	}
}
