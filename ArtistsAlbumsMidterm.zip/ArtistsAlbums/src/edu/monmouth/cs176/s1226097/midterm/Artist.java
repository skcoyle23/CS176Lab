package edu.monmouth.cs176.s1226097.midterm;

import java.util.ArrayList; 

public class Artist 
{
	//Initializes private variables
	private String artistFirstName;
	private String artistLastName; 
	private String bandPosition; 
	private String bandName; 
	
	ArrayList<Album> album = new ArrayList<Album>(); 
	
	/**
	 * initializes the artist object
	 * @param artistFN
	 * @param artistLN
	 * @param bandPos
	 */
	Artist(String artistFN, String artistLN, String bandPos, String bandName)
	{
		this.artistFirstName = artistFN; 
		this.artistLastName = artistLN; 
		this.bandPosition = bandPos; 
		this.bandName = bandName; 
	}
	
	//Initiate to be able to use in Album Class
	public Artist(Artist a)
	{
		this(a.artistFirstName, a.artistLastName, a.bandPosition, a.bandName); 
	}
	
	public void addBandPos(String newBandPos)
	{
		bandPosition = bandPosition.concat(", " +newBandPos); 
	}
	
	public String toString()
	{
		return "	ARTIST NAME: " +this.artistFirstName+this.artistLastName+ "\n"+
				"	BAND POSITION: " +this.bandPosition+ "\n"+
				"        BAND NAME: " +this.bandName; 
	}
	public String getName()
	{
		return this.artistFirstName+" "+this.artistLastName; 
	}
	
	//Adds album
	public void addAlbum(Album a)
	{
		this.album.add(a); 
	}
}
