package edu.monmouth.cs176.s1226097.midterm;

import java.util.ArrayList; 

public class ArtistList 
{
	//Creates an artist arrayList to hold the artists and albums
	ArrayList<Artist> artist = new ArrayList<Artist>(); 

	//Constructor for ArtistList
	ArtistList()
	{

	}

	/**
	 * @param a - new artist object
	 */
	public void addArtist(Artist a)
	{
		artist.add(a); 
	}
	//Lists artists
	public void listArtists()
	{
		for(Artist a: artist)
		{
			System.out.println("ARTIST: "); 
			System.out.println(a.toString()); 
			System.out.println(); 

			System.out.println("ALBUMS: "); 
			for(Album al: a.album)
			{
				System.out.println(al.toString()); 
			} 
			System.out.println();
		}
	}
}
