package edu.monmouth.cs176.s1226097.midterm;

public class Album extends Artist
{
	//Initializes private variables
	private String albumName; 
	private int albumRelease; 

	//Creates the "Album" class
	Album(String album, Artist artist, int alRelease)
	{
		super(artist); 
		this.albumName = album; 
		this.albumRelease = alRelease; 
	}
	
	public void setAlbumName(String newAlbum)
	{
		this.albumName = newAlbum; 
	}

	public void setAlbumRelease(int alRelease)
	{
		this.albumRelease = alRelease; 
	}
	
	public String toString()
	{
		return "	ALBUM: " +this.albumName+ "\n"+
				"           ALBUM RELEASE IN: " +this.albumRelease; 
	}
}
