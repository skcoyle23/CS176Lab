package edu.monmouth.cs176.s1226097.midterm;

public class ArtistsAlbums 
{
	public static void main(String[] args)
	{
		ArtistList artists = new ArtistList(); 
		
		//Create artists
		Artist a1 = new Artist("Post ", "Malone", "Singer", "N/A"); 
		Artist a2 = new Artist("Thomas ", "Rhett", "Singer", "N/A");
		Artist a3 = new Artist("Mac", " Miller", "Singer", "N/A"); 
		
		//Adds artists to list
		artists.addArtist(a1); 
		
		a1.addBandPos("Guitar");
		
		//Create albums
		Album al1 = new Album("Stoney", a1, 2016); 
		Album al2 = new Album("beerbongs & bentleys", a1, 2018); 
		Album al3 = new Album("Hollywood's Bleeding", a1, 2019); 

		Album tr1 = new Album("It Goes Like This", a2, 2013); 
		Album tr2 = new Album("Tangled Up", a2, 2015); 
		Album tr3 = new Album("Life Changes", a2, 2017); 
		Album tr4 = new Album("Center Point Road", a2, 2019);
		
		Album mm1 = new Album("Blue Slide Park", a3, 2011); 
		Album mm2 = new Album("Macadelic", a3, 2012);
		Album mm3 = new Album("Watching Movies with the Sound Off", a3, 2013);
		Album mm4 = new Album("Live from Space", a3, 2013);
		Album mm5 = new Album("GO:OD AM", a3, 2015);
		Album mm6 = new Album("The Divine Feminine", a3, 2016); 
		Album mm7 = new Album("Swimming", a3, 2018); 
		
		//Add albums to the list
		a1.addAlbum(al1);
		a1.addAlbum(al2);
		a1.addAlbum(al3);
		
		//Adds artist 2 
		artists.addArtist(a2);
		
		a2.addAlbum(tr1);
		a2.addAlbum(tr2);
		a2.addAlbum(tr3);
		a2.addAlbum(tr4);
		
		//Adds artist 3 and albums
		artists.addArtist(a3);
		
		a3.addAlbum(mm1);
		a3.addAlbum(mm2);
		a3.addAlbum(mm3);
		a3.addAlbum(mm4);
		a3.addAlbum(mm5);
		a3.addAlbum(mm6);
		a3.addAlbum(mm7);
		
		//Lists artists and their albums
		artists.listArtists(); 
	}
}
