package edu.monmouth.cs176.s1226097.lab01;

public class Student 
{
	//Intializes private variables
	private String name; 
	private String studentID; 
	private String email; 
	private String major; 
	private Integer classLevel; 
	private String advisor; 
	private Double credits; 
	private Integer graduationYear; 

	/**
	 * @param name - full name
	 * @param sID - student ID
	 * @param email - school email
	 * @param major - student's major
	 * @param classLevel - class level 1 through 4
	 * @param advisor - students's advisor
	 * @param credits - course credit
	 * @param graduationYear - grad year YYYY
	 */

	//Initializes Student class and input
	Student (String name, String sID, String email, String major, Integer classLevel, String advisor, Double credits, Integer graduationYear)
	{
		this.name = name; 
		this.studentID = sID; 
		this.email = email; 
		this.major = major; 
		this.classLevel = classLevel; 
		this.advisor = advisor; 
		this.credits = credits; 
		this.graduationYear = graduationYear; 
	}
	
	/**
	 * Getter method for major
	 * @param major
	 */
	 public void setMajor(String major)
	 {
		 this.major = major; 
	 }
	 
	 //over object to return STRING
	 public String getMajor()
	 {
		 return this.major; 
	 }
	 
	 //Setter for gradYear
	 public void setGraduationYear(Integer graduationYear)
	 {
		 this.graduationYear = graduationYear; 
	 }
	 
	 public String getStudentID()
	 {
		 return this.studentID; 
	 }
	 
	 public String getStudentEmail()
	 {
		 return this.email; 
	 }
	 
	 /* (non-Javadoc)
	  * @see java.lang.Object#toString()
	  */
	 
	 //Sets information to String to print out
	 public String toString()
	 {
		 return
				 "Name: " +this.name+ "\n"+
				 "Student ID: " +this.studentID+ "\n"+
				 "Email: " +this.email+ "\n"+
				 "Major: " +this.major+ "\n"+
				 "Class: " +this.classLevel+ "\n"+
				 "Advisor: " +this.advisor+ "\n"+
				 "Credits: " +this.credits+ "\n"+
		 		 "Graduation Year: " +this.graduationYear+ "\n";
	 }

}
