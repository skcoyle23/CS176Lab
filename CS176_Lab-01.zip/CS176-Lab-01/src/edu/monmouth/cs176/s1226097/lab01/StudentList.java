package edu.monmouth.cs176.s1226097.lab01;

public class StudentList 
{
	Student[] cs176Students; 
	
	private int count = 0; 
	
	//Constructor for StudentList class
	StudentList(int totalStudents)
	{
		cs176Students = new Student[totalStudents]; 
	}
	
	/*
	 * @param s - new student object
	 */
	public void addStudent(Student s)
	{
		cs176Students[count] = s; 
		count++; 
	}
	
	//List the students using FOR-EACH LOOP
	public void listStudents()
	{
		for (Student s: cs176Students)
		{
			System.out.println(s.toString()); 
		}
	}
}
