package edu.monmouth.s1226097.cs176;

public class Vehicle 
{
	private Integer fuelTank; 
	private Double mpg; 
	
	//Vehicle constructor to initialize instance variables ^^
	Vehicle(Integer ft, Double initMPG)
	{
		fuelTank = ft; 
		mpg = initMPG; 
	}
	
	Vehicle()
	{
		
	}
	
	public void setMPG(double newMPG)
	{
		this.mpg = newMPG; 
	}
	public double getMPG()
	{
		return this.mpg; 
	}
	
	public double getFuel()
	{
		return this.fuelTank; 
	}
	
	//Computes how many refuel stops are needed given the travel distance 
	public int numberOfStops(Double travelDist)
	{
		double carRange = mpg * this.fuelTank; 
		int stops = (int) (travelDist / carRange); 
		// System.out.println("Number of Stops: "); 
		
		if (stops * mpg * fuelTank == travelDist) {
			stops--;
		}
		return stops; 
	}
	
	public String toString()
	{
		return "MPG = " +this.getMPG()+
				" "
				+ "Fuel Tank = " +this.getFuel(); 
	}
}
