package edu.monmouth.s1226097.cs176;

public class PassengerCar extends Vehicle
{
	private Integer passengers; 
	
	PassengerCar(Integer ft, Double mpg, Integer pass) //Assume mpg doesn't change significantly
	{
		super(ft, mpg); 
		passengers = pass; 
	}
	
	public String toString()
	{
		String vehicleInfo = super.toString(); 
		return vehicleInfo+ " "
				+ "There are " +this.passengers+ " passengers."; 
	}
}
