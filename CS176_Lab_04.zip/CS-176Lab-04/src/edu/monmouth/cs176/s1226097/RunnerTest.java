package edu.monmouth.cs176.s1226097;

public class RunnerTest {

	public static void main(String[] args) {
		RunnerList runners = new RunnerList();

		// 1. get total count of Registered runners. Print the value
		System.out.println("TOTAL COUNT OF RUNNERS: " +runners.totalRunners()); 

		// 2. get total count of t-shirts for size XS, S, M, L, XL, 2XL, 3XL
		//    print individual size counts
		int xsCount = runners.getTshirtCount("XS");
		System.out.println("XS COUNT: " +xsCount); 
		int sCount = runners.getTshirtCount("S"); 
		System.out.println("S COUNT: " +sCount); 
		int mCount = runners.getTshirtCount("M");
		System.out.println("M COUNT: " +mCount);
		int lCount = runners.getTshirtCount("L"); 
		System.out.println("L COUNT: " +lCount);
		int xlCount = runners.getTshirtCount("XL");
		System.out.println("XL COUNT: " +xlCount);
		int xl2Count = runners.getTshirtCount("2XL");
		System.out.println("2XL COUNT: " +xl2Count);
		int xl3Count = runners.getTshirtCount("3XL");
		System.out.println("3XL COUNT: " +xl3Count);

		// 3. get sum of t-shirt sizes
		//    print to verify the count adds up value in 1. above
		int tshirtSum = 0; 
		tshirtSum = xsCount + sCount + mCount + lCount +xlCount + xl2Count +xl3Count; 
		System.out.println("SUM OF T-SHIRT SIZES: " +tshirtSum); 
		System.out.println(); 

		// 4. Select a valid runner to delete 
		//    if found print "runner deleted" and total runners count
		//    else not found

		boolean delete = runners.deleteRunner("1002"); 

		if(delete)
		{
			System.out.println("Runner deleted. Now there are " +runners.totalRunners()+ " runners"); 
		}
		else
		{
			System.out.println("Runner not found."); 
		}

		// 4a. Select a runner to delete 
		//    if found print "runner deleted" and total runners count
		//    else not found

		// Hint: Can we implement a method here to do steps 4 and 4a?

		//Extra Credit
		
	}

}