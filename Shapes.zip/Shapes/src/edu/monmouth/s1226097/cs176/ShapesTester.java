package edu.monmouth.s1226097.cs176;

public class ShapesTester 
{
	public static void main(String[] args)
	{
		Triangle t1 = new Triangle("Blue Triangle", 2, 3); 
		Triangle t2 = new Triangle("Dotted Triangle", 18, 18); 
		Triangle t3 = new Triangle("Red Triangle", 14.678, 4.56); 
		Triangle t4 = new Triangle("Solid Triangle", 123.45, 34.5); 
		
		t1.showStyle();
		t1.showDim();
		t1.setHeight(4.5);
		t1.showDim(); 
		System.out.println("Area of Triangle: " +t1.compArea());
		System.out.println(); 
		
		t2.showStyle();
		t2.showDim(); 
		System.out.println("Area of Triangle: " +t2.compArea());
		
		t2.showStyle();
		t2.showDim(); 
		System.out.println("Area of Triangle: " +t2.compArea());
		System.out.println(); 
		
		t3.showStyle();
		t3.showDim(); 
		t3.setWidth(15.67);
		t3.showDim();
		t3.setHeight(4.55);
		t3.showDim();
		System.out.println("Area of Triangle: " +t3.compArea());
		System.out.println(); 
		
		t4.showStyle();
		t4.showDim(); 
		t4.setWidth(124.56);
		t4.showDim();
		System.out.println("Area of Triangle: " +t4.compArea());
		System.out.println(); 
		
		//Extra Credit
		Circle c1 = new Circle(4, 10); 
		Circle c2 = new Circle(10.86, 20); 
		
		c1.showDim();
		System.out.println("Area of Circle: " +c1.compCirArea()); 
		System.out.println(); 
		
		c2.showDim();
		c2.setWidth(12.64);
		c2.showDim();
		System.out.println("Area of Circle: " +c2.compCirArea()); 
	}
}
