package edu.monmouth.s1226097.cs176;

public class TwoDShape 
{
	private double width; 
	private double height; 
	
	TwoDShape(double x) //Assume the width and height are x
	{
		this.width = x; 
		this.height = x; 
	}
	
	TwoDShape(double w, double h)
	{
		this.width = w; 
		this.height = h; 
	}
	
	public void setWidth(double w)
	{ 
		this.width = w; 
	}
	
	public void setHeight(double h)
	{
		this.height = h; 
	}
	
	public double getWidth()
	{
		return this.width; 
	}
	
	public double getHeight()
	{
		return this.height; 
	}
	
	public void showDim()
	{
		System.out.println("Width and height are " +width+ " X " +height); 
	}
}
