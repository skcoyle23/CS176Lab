package edu.monmouth.s1226097.cs176;

public class Triangle extends TwoDShape
{
	private String style; 
	
	Triangle(double x) //Assume the style is none
	{
		super(x); 
		style = "none"; 
	}
	
	Triangle(String s, double w, double h)
	{
		super(w, h); 
		this.style = s; 
	}
	
	public void showStyle()
	{
		System.out.println("Style of Triangle: " +style); 
	}
	
	//A method to compute and return the area
	public double compArea()
	{
		double area = 0; 
		area = (this.getWidth() * this.getHeight()) / 2; //A = (base * height) / 2
		
		return area; 
	}
}
