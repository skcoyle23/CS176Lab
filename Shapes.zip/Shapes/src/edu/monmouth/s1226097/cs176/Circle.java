package edu.monmouth.s1226097.cs176;

public class Circle extends TwoDShape
{
	Circle(double x)
	{
		super(x); 
	}
	
	Circle(double w, double h)
	{
		super(w, h); 
	}
	
	public double compCirArea()
	{
		double area = 0; 
		area = Math.PI * (Math.pow(this.getWidth(), 2)); 
		
		return area; 
	}
}
