package edu.monmouth.cs176.s1226097.lab03;

public class Lab03Test 
{
	public static void main (String[] args)
	{
		System.out.println("Lab 3: "); 
		
		//Initiate StudentList class
		StudentList cs176List = new StudentList(15);
		
		//Initiate a student
		Student s1 = new Student("Ahmed, Saahil", "1219200", "s1219200@monmouth.edu", "CS", 2, "E. Cesario", 1.0, 2022); 
		Student s2 = new Student("Berardis, Anthony", "1297598", "s1297598@monmouth.edu", "CS", 2, "R. Sherl", 1.0, 2022);
		Student s3 = new Student("Clappsy, Thomas", "1218375", "s1218375@monmouth.edu", "CS", 2, "J.Kretsch", 1.0, 2022);
		Student s4 = new Student("Coyle, Shannon", "1226097", "s1226097@monmouth.edu", "SE", 2, "J.Kretsch", 1.0, 2022);
		Student s5 = new Student("Fahad, Muhammad", "1212339", "s1212339@monmouth.edu", "CS", 2, "E. Cesario", 1.0, 2022);
		Student s6 = new Student("Johnson, Spencer", "1224708", "s1224708@monmouth.edu", "CS", 2, "J.Chung", 1.0, 2022);
		Student s7 = new Student("Jones, Matthew", "1095689", "s1095689@monmouth.edu", "CS", 2, "R. Scherl", 1.0, 2022);
		Student s8 = new Student("Kliks, Angela", "1137151", "s1137151@monmouth.edu", "CS", 2, "L. Zheng", 1.0, 2022);
		Student s9 = new Student("Krempa, Ian", "1233625", "s1233625@monmouth.edu", "CS", 2, "C. Yu", 1.0, 2022);
		Student s10 = new Student("Marquez, Veronica", "1125739", "s1125739@monmouth.edu", "CS", 3, "J. Kretsch", 1.0, 2021);
		Student s11 = new Student("McKnight, Anthony", "1249736", "s1249736@monmouth.edu", "CS", 2, "C. Yu", 1.0, 2022);
		Student s12 = new Student("Patel, Premkumar", "1205153", "s1205153@monmouth.edu", "CS", 2, "L. Zheng", 1.0, 2022);
		Student s13 = new Student("Patel, Sahil", "1245759", "s1245759@monmouth.edu", "CS", 2, "J. Kretsch", 1.0, 2022);
		Student s14 = new Student("Robinson, Annabelle", "1212304", "s1212304@monmouth.edu", "CS", 2, "J. Kretsch", 1.0, 2022);
		Student s15 = new Student("Vella, Nicholas", "0999371", "s0999371@monmouth.edu", "CS", 4, "G. Eckert", 1.0, 2020);
		
		
		//Add students to the list
		cs176List.addStudent(s1);
		cs176List.addStudent(s2);
		cs176List.addStudent(s3);
		cs176List.addStudent(s4);
		cs176List.addStudent(s5);
		cs176List.addStudent(s6);
		cs176List.addStudent(s7);
		cs176List.addStudent(s8);
		cs176List.addStudent(s9);
		cs176List.addStudent(s10);
		cs176List.addStudent(s11);
		cs176List.addStudent(s12);
		cs176List.addStudent(s13);
		cs176List.addStudent(s14);
		cs176List.addStudent(s15);
		
		cs176List.listStudents();
		
		boolean update = cs176List.updateStudentGraduationYear("2126097", 2026); 
		
		if(update)
		{
			cs176List.listStudents(); 
		}
		else
		{
			System.out.println("CANNOT FIND STUDENT TO UPDATE"); 
		}
		System.out.println(); 
		
		System.out.println("TOTALS: "); 
		Integer csCount = cs176List.studentCount("CS"); //Argument 
		System.out.println("Total Students in CS: " +csCount);
		Integer csCount2 = cs176List.studentCount("HIS"); //Argument 
		System.out.println("Total Students in HIS: " +csCount2);
		Integer csCount3 = cs176List.studentCount("SE"); //Argument 
		System.out.println("Total Students in SE: " +csCount3);
		System.out.println(); 
		 
		/*Student update2 = cs176List.getStudentInfo("s1226097@monmouth.edu"); 
		if(update2 != null)
		{
			System.out.println("Student with email is: ");
			System.out.print(update2);
		}
		else
		{
			System.out.println("Student not found"); 
		}
		System.out.println(); 
		*/
		
		Student findStud = cs176List.findStudentByKey("ID", "1226097"); 
		if(findStud != null)
		{
			System.out.println("STUDENT FOUND BY KEY IS: "); 
			System.out.println(findStud); 
		}
		else
		{
			System.out.print("STUDENT NOT FOUND."); 
		}
	}
}
