package edu.monmouth.cs176.s1226097.lab03;

import java.util.ArrayList; 

class ArrayListClass
{
	ArrayList<String> Student = new ArrayList<String>(); 
}
